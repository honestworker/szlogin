<template>
	<div>
		<p class="text-center"><small>Designed with love by <a href="http://wmlab.in" target="_blank">WMLab</a> | Theme by <a href="http://wrappixel.com" target="_blank">Wrappixel</a></small></p>
	</div>
</template>


<script>
    export default { }
</script