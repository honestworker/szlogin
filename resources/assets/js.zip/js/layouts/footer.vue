<template>
	<footer class="footer">
        Designed with love by <a href="http://wmlab.in" target="_blank">WMLab</a> | Theme by <a href="http://wrappixel.com" target="_blank">Wrappixel</a>
    </footer>
</template>

<script>
    export default {
        mounted() {
        }
    }
</script>